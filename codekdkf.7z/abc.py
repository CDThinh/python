import pygame
pygame.init()
clock = pygame.time.Clock()
screen = pygame.display.set_mode((600, 300))
#tieu de icon
pygame.display.set_caption("=)))")
icon = pygame.image.load(r'monkey.png')
#load hinh anh 
bg = pygame.image.load(r'background.jpg')
tree = pygame.image.load(r'snake.png')
monkey = pygame.image.load(r'monkey.png')
#khoi tao
score, hscore = 0, 0
bg_x, bg_y = 0, 0
tree_x, tree_y = 550, 230
monkey_x, monkey_y = 0, 230
x_def = 5
y_def = 5
jump = False
gameplay = True
#ham check va cham
def checkvc():
     if monkey_hcn.colliderect(tree_hcn):
        return False
     return True
#dưa diem vao game
game_font = pygame.font.Font('04B_19.TTF', 20)
def score_view():
    if gameplay:
        score_txt = game_font.render(f'SCORE: {int(score)}', True, (255,0,0))
        screen.blit(score_txt,(250, 50))
        hscore_txt = game_font.render(f'HIGH SCORE: {int(hscore)}', True, (255,0,0))
        screen.blit(hscore_txt,(450, 50))
    else:
        score_txt = game_font.render(f'SCORE: {int(score)}', True, (255,0,0))
        screen.blit(score_txt,(250, 50))
        hscore_txt = game_font.render(f'HIGH SCORE: {int(hscore)}', True, (255,0,0))
        screen.blit(hscore_txt,(450, 50))
#vong lap xu li game
running = True
while running:
    #chinh FPS
    clock.tick(60)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN and gameplay:
                if monkey_y == 230:
                    jump = True
        if event.type == pygame.MOUSEBUTTONDOWN and gameplay == False:
             gameplay = True
    if gameplay:
        #bg
        bg_hcn = screen.blit(bg, (bg_x, bg_y))
        bg2_hcn = screen.blit(bg, (bg_x + 600, bg_y))
        bg_x -= x_def
        if bg_x == -600: bg_x = 0
        #tree
        tree_hcn = screen.blit(tree, (tree_x, tree_y))
        tree_x -= x_def
        if tree_x == -20: tree_x = 550
        #monkey
        monkey_hcn = screen.blit(monkey, (monkey_x, monkey_y))
        if monkey_y >= 80 and jump:
            monkey_y -= y_def
        else:
            jump = False
        if monkey_y  < 230 and jump == False:
            monkey_y += y_def
        score += 0.01
        if hscore < score: hscore = score
        gameplay = checkvc()
        score_view()
    else:
        #rest game
        bg_x, bg_y = 0, 0
        tree_x, tree_y = 550, 230
        monkey_x, monkey_y = 0, 230
        bg_hcn = screen.blit(bg, (bg_x, bg_y))
        tree_hcn = screen.blit(tree, (tree_x, tree_y))
        monkey_hcn = screen.blit(monkey, (monkey_x, monkey_y))
        score = 0  
        score_view()
    pygame.display.update()

